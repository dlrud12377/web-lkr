package com.korea.movie_reservation.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.korea.movie_reservation.vo.ReservationVO;

@Mapper
public interface ReservationDAO {

	Integer insert(ReservationVO reservation);

	Integer update(Integer reservationId, ReservationVO updatedReservation);

	List<ReservationVO> findReservationDetails();

}
